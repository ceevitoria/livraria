// jCompany 6.0 : Arquivo Javascript específico da aplicação.
// É inserido e disponibilizado em todas as páginas