package com.cee.livraria.entity.config;

import com.cee.livraria.entity.AppBaseEntity;

public abstract class Config extends AppBaseEntity {

}
