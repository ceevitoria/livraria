package com.cee.livraria.entity;

/**
 * Interface Estocavel
 */
public interface Estocavel {
	
}
