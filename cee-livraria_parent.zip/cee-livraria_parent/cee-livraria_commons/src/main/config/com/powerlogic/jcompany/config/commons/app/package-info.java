/* ****************************** META-DADOS COMUNS DA APLICAÇÃO ****************************
  ********************** Defaults de Valores de Declaração Global ****************************
  ************** Deve ser empacotado em todas as camadas - WAR e JARs EJBs, quando remotos ***
  *******************************************************************************************/

package com.powerlogic.jcompany.config.commons.app;

