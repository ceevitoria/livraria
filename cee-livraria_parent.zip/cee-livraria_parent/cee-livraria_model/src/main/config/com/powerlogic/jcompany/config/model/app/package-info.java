/* ****************************** META-DADOS MODELO DA APLICAÇÃO ******************************
  ********************** Defaults de Valores de Declaração de Modelo ************************
  ********************** Deve ser empacotado em aplicações WAR ******************************
  *******************************************************************************************/

package com.powerlogic.jcompany.config.model.app;
