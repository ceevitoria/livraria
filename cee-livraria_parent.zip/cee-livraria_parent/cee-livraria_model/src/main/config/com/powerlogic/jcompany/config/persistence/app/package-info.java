/* ************************ META-DADOS PERSISTENCIA DA APLICAÇÃO ******************************
  ********************** Defaults de Valores de Declaração de Persistencia ******************
  ********************** Deve ser empacotado em aplicações WAR ******************************
  *******************************************************************************************/

package com.powerlogic.jcompany.config.persistence.app;
